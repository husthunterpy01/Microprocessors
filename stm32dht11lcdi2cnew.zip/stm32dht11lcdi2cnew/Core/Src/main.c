/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "i2c-lcd.h"
#include "stdio.h"
#include "stm32f1xx.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */


#define AIN1_GPIO_Port GPIOA 
#define AIN2_GPIO_Port GPIOA
#define AIN1_Pin GPIO_PIN_6
#define AIN2_Pin GPIO_PIN_7
/*
#define PWM_PERIOD 1099 // PWM period = (72 MHz/65535) -1 ~ 1099
#define PWM_MIN_DUTY_CYCLE 0 //Minimum duty cycle (0%)
#define PWM_MAX_DUTY_CYCLE 999 //Maximum duty cycle (100%)
*/
#define max_temp 40.0 
#define min_temp 25.0
/*
#define KP 50.0
#define KI 0.5
#define KD 10.0
*/




/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim4;

/* USER CODE BEGIN PV */
typedef enum
{
	CW,
	STOP,
}MotSet;


/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C1_Init(void);
static void MX_TIM4_Init(void);
static void MX_TIM1_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/*
float kp = KP;
float ki = KI;
float kd = KD;

float integral = 0.0;
float prev_error = 0.0;
*/
/*
float temp_speed_map[5][2] = {
	{min_temp, 0}, // if temp <= 25, speed = 0%
	{30.0, 200},  // if 25 < temp <= 30, speed = 20%
	{35.0, 400},	// if 30 < temp <=35 , speed = 40%
	{40.0, 600},	// if 35 < temp <=40 , speed = 60%
	{100.0,999},	// if temp > 40 , speed = 100%
};
*/

/*
float get_target_speed(float temperature)
{
    int i;
    for (i = 0; i < 4; i++)
    {
        if (temperature <= temp_speed_map[i][0])
            return temp_speed_map[i][1];
    }
    return temp_speed_map[3][1];
}
*/

void MotControl(MotSet motset, uint8_t speed)
{
	if (speed >= 100)
	{
		TIM1 -> CCR1 = TIM1 -> ARR + 1;
	}
	else
	{
		TIM1 -> CCR1 = speed*0.01*(TIM1 -> ARR + 1);
	}
	
	switch(motset)
	{
		case CW:
			HAL_GPIO_WritePin(AIN1_GPIO_Port, AIN1_Pin, GPIO_PIN_SET);
			HAL_GPIO_WritePin(AIN2_GPIO_Port, AIN2_Pin, GPIO_PIN_RESET);
			break;
		
		case STOP:
			HAL_GPIO_WritePin(AIN1_GPIO_Port, AIN1_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(AIN2_GPIO_Port, AIN2_Pin, GPIO_PIN_RESET);
			TIM1 -> CCR1 = 0;
			break;
	}
}
/*
void MotControl(MotSet motset, uint8_t power_percent)
{
	if (power_percent >= 100)
	{
		TIM4 -> CCR1 = TIM4 -> ARR + 1;
	}
	else
	{
		TIM4 -> CCR1 = power_percent*0.01*(TIM4 -> ARR + 1);
	}
	
	switch(motset)
	{
		case CW:
			HAL_GPIO_WritePin(AIN1_GPIO_Port, AIN1_Pin, GPIO_PIN_SET);
			HAL_GPIO_WritePin(AIN2_GPIO_Port, AIN2_Pin, GPIO_PIN_RESET);
			break;
		
		case STOP:
			HAL_GPIO_WritePin(AIN1_GPIO_Port, AIN1_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(AIN2_GPIO_Port, AIN2_Pin, GPIO_PIN_RESET);
			TIM4 -> CCR1 = 0;
			break;
	}
}
*/


//delay function in microseconds
void delay (uint16_t time)
{
	__HAL_TIM_SET_COUNTER(&htim4, 0);
	while ((__HAL_TIM_GET_COUNTER(&htim4)) < time);
}


void set_motor_speed(float temp)
{
	if (temp < min_temp)
	{
		//set motor speed to 0%
		HAL_GPIO_WritePin(AIN1_GPIO_Port, AIN1_Pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(AIN2_GPIO_Port, AIN2_Pin, GPIO_PIN_RESET);
	}
	else if (temp >= min_temp && temp < 30.0)
	{
		MotControl(CW, 20);
	}	
	else if (temp >= 30.0 && temp < 35.0)
	{
		MotControl(CW, 40);
	}
	else if (temp >= 35.0 && temp < max_temp)
	{
		MotControl(CW, 75);
	}
	else if (temp > max_temp)
	{
		HAL_GPIO_WritePin(AIN1_GPIO_Port, AIN1_Pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(AIN2_GPIO_Port, AIN2_Pin, GPIO_PIN_SET);
	}
	
	/*
	{
		
		//set motor speed proportional to temperature
		//HAL_GPIO_WritePin(AIN1_GPIO_Port, AIN1_Pin, GPIO_PIN_SET);
		//HAL_GPIO_WritePin(AIN2_GPIO_Port, AIN2_Pin, GPIO_PIN_RESET);
		float speed = (temp - min_temp) * (100.0/(max_temp-min_temp));
		//uint16_t duty_cycle = (uint16_t)(speed * 65535.0 / 100.0);
		uint16_t duty_cycle = (uint16_t)(speed * (TIM4->ARR + 1) / 100);
		TIM4 -> CCR1 = duty_cycle;
		//MotControl(CW, duty_cycle);
		
	}*/
}

/*
void calculatepid (float temp)
{
	 // Calculate temperature error
        float target_speed = get_target_speed(temp);
        float current_speed = HAL_TIM_ReadCapturedValue(&htim4, TIM_CHANNEL_1) * 1000 / PWM_PERIOD;
        float error = target_speed - current_speed;

 

        // Calculate PID output
        integral += error;
        float derivative = error - prev_error;
        float output = kp * error + ki * integral + kd * derivative;

 

        // Limit output to PWM duty cycle range
        if (output > PWM_MAX_DUTY_CYCLE)
            output = PWM_MAX_DUTY_CYCLE;
        else if (output < PWM_MIN_DUTY_CYCLE)
            output = PWM_MIN_DUTY_CYCLE;

 

        // Set PWM duty cycle
        __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_1, output);

 

        prev_error = error;
}

*/


//Function to display temperature
void Display_Temp (float Temp)
{
	char str[20] = {0};
	lcd_put_cur(0,0);
	
	sprintf (str, "TEMP:  %.2f", Temp);
	lcd_send_string(str);
	lcd_send_data('C');
}

//function to display RH
void Display_Rh (float Rh)
{
	char str[20] = {0};
	lcd_put_cur(1,0);
	
	sprintf (str, "HUMID: %.2f", Rh);
	lcd_send_string(str);
	lcd_send_data('%');
}
	
//variables declarations
uint8_t Rh_byte1, Rh_byte2, Temp_byte1, Temp_byte2;
uint16_t SUM, RH, TEMP;

float Temperature ;
float Humidity ;
uint8_t Presence = 0;

//function to set the pins as outputs
void Set_Pin_Output(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	GPIO_InitStruct.Pin = GPIO_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOx, &GPIO_InitStruct);
}

//function to set pin as input
void Set_Pin_Input(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	GPIO_InitStruct.Pin = GPIO_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	GPIO_InitStruct.Pull = GPIO_PULLUP; //can be changed to PULLUP if no data is received from the pin
	HAL_GPIO_Init(GPIOx, &GPIO_InitStruct);
}

/***************************DHT11 FUNCTIONS BEGIN HERE**********************************************/

//Define the pin and the port for DHT11 Sensor
#define DHT11_PORT GPIOA
#define DHT11_PIN GPIO_PIN_1
//Function to send the start signal
void DHT11_Start (void) 
{
	Set_Pin_Output (DHT11_PORT, DHT11_PIN); //set the dht pin as output
	/***********************************************/
	HAL_GPIO_WritePin(DHT11_PORT, DHT11_PIN, 1); //initialize with data pin high
	HAL_Delay(1000); //wait for 1000 milliseconds
	/***********************************************/

	HAL_GPIO_WritePin (DHT11_PORT, DHT11_PIN, 0); //pull the pin low
	delay(18000); //wait 18 milliseconds
	HAL_GPIO_WritePin (DHT11_PORT, DHT11_PIN, 1); //pull the pin high
	delay(20); //wait for 20 microseconds
	Set_Pin_Input(DHT11_PORT, DHT11_PIN); //set the pin as input
}

//dh11 function to check response
uint8_t DHT11_Check_Response (void) 
{
	uint8_t Response = 0;
	delay(40); //first wait for 40 microseconds
	if (!(HAL_GPIO_ReadPin (DHT11_PORT, DHT11_PIN))) //check for pin to be low
	{
		delay(80); //wait for 80 microseconds
		if((HAL_GPIO_ReadPin (DHT11_PORT, DHT11_PIN))) Response = 1; //check if pin is high and return 1 to show sensor is present
		else Response = -1; //255
	}
	while ((HAL_GPIO_ReadPin (DHT11_PORT, DHT11_PIN))); //wait for the pin to go low again
	
	return Response;
}

//function to read data from dht11 signal pin
uint8_t DHT11_Read (void)
{
	uint8_t i, j;
	for (j=0;j<8;j++)
	{
		while(!(HAL_GPIO_ReadPin (DHT11_PORT, DHT11_PIN))); //wait for the pin to change to high
		delay(40); //wait for 40 microseconds
		if (!(HAL_GPIO_ReadPin (DHT11_PORT, DHT11_PIN))) //if the pin is low
		{
			i&= ~(1<<(7-j)); //write 0
		}
		else i|= (1<<(7-j)); //if the pin is high write 1
		while ((HAL_GPIO_ReadPin (DHT11_PORT, DHT11_PIN))); //wait for the pin to go low
	}
	
	return i;
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C1_Init();
  MX_TIM4_Init();
  MX_TIM1_Init();
  /* USER CODE BEGIN 2 */
	
	HAL_TIM_Base_Start(&htim4);
	HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
	
	TIM1 -> CCR1 = 1000;
	HAL_GPIO_WritePin(AIN1_GPIO_Port, AIN1_Pin, GPIO_PIN_SET);
	HAL_GPIO_WritePin(AIN2_GPIO_Port, AIN2_Pin, GPIO_PIN_RESET);
	
	
	
	
	lcd_init(); //initialize lcd
	lcd_send_string("INITIALIZING.."); //display string on lcd
	HAL_Delay(1000); //wait for 1 seconds
	lcd_clear();
	
	
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
		set_motor_speed(Temperature);
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
		
		
		
		//set_motor_speed(Temperature);
		Display_Temp(Temperature);
		Display_Rh(Humidity);
		
		/*******DHT11*********/
		DHT11_Start();
		Presence = DHT11_Check_Response(); //record the response from the sensor
		
		//Five bytes of data
		Rh_byte1 = DHT11_Read ();
		Rh_byte2 = DHT11_Read ();
		Temp_byte1 = DHT11_Read ();
		Temp_byte2 = DHT11_Read ();
		SUM = DHT11_Read ();
		
		
		TEMP = Temp_byte1;
		RH = Rh_byte1;
		
		Temperature = (float) TEMP;
		Humidity = (float) RH;
	
		
		
		
		
		HAL_Delay(1200);
  }
	
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 100000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 0;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 65535;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim1, &sBreakDeadTimeConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */
  HAL_TIM_MspPostInit(&htim1);

}

/**
  * @brief TIM4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM4_Init(void)
{

  /* USER CODE BEGIN TIM4_Init 0 */

  /* USER CODE END TIM4_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM4_Init 1 */

  /* USER CODE END TIM4_Init 1 */
  htim4.Instance = TIM4;
  htim4.Init.Prescaler = 72-1;
  htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim4.Init.Period = 0xffff-1;
  htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim4) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim4, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM4_Init 2 */

  /* USER CODE END TIM4_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, DHT11_Pin|GPIO_PIN_6|GPIO_PIN_7, GPIO_PIN_RESET);

  /*Configure GPIO pins : DHT11_Pin PA6 PA7 */
  GPIO_InitStruct.Pin = DHT11_Pin|GPIO_PIN_6|GPIO_PIN_7;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
